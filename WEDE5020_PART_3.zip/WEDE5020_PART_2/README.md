# The Second Chance Youth Foundation Website

## 1. Project Overview

The Second Chance Youth Foundation website is designed to provide information and support to young adults transitioning from children's homes, foster care and alternative care into independent living.

The website provides information about the foundation, its mission, vision, values, programmes and services. It also allows visitors to make enquiries and contact the organisation.

## 2. Website Objectives

The main objectives of the website are:

- To introduce visitors to The Second Chance Youth Foundation.
- To explain the foundation's mission, vision and values.
- To provide information about the programmes and services offered.
- To allow visitors to submit enquiries.
- To provide contact information for people who need assistance or want to support the foundation.
- To improve the user experience through responsive design and interactive functionality.

## 3. Website Pages

The website consists of five main pages:

| Page | Description |
|---|---|
| index.html | The homepage introduces the foundation and its purpose. |
| about.html | Provides information about the foundation, its history, mission, vision and values. |
| services.html | Describes the programmes and services offered by the foundation. |
| enquiry.html | Allows visitors to enquire about services, volunteering and sponsorship. |
| contact.html | Provides contact information and a form for general messages. |

## 4. Technologies Used

The website uses the following technologies:

- HTML5 – Used to structure the website content.
- CSS3 – Used to style the website and create its layout.
- JavaScript – Used to add interactive functionality and form validation.
- GitHub – Used for version control and hosting the project repository.

## 5. Website Functionality

The website includes the following functionality:

- Navigation links to move between the website pages.
- A service search feature to help visitors find specific services.
- A category filter for displaying relevant services.
- An accordion feature to display frequently asked questions.
- An image gallery with a lightbox feature.
- Form validation to check that required information is entered.
- Character counters for message fields.
- A contact form that prepares an email using the visitor's email application.
- An automatically updated copyright year.

The enquiry form currently demonstrates client-side validation and displays a response to the visitor. It does not store or send enquiry information to a server.

## 6. Search Engine Optimisation (SEO)

SEO improvements include:

- Page titles that describe the content of each page.
- Meta descriptions for search engine results.
- Relevant keywords.
- Descriptive image alternative text.
- Appropriate heading structures.
- Internal links between website pages.
- A robots.txt file to provide instructions to search engine crawlers.
- A sitemap.xml file listing the website pages.

## 7. Responsive Design and Accessibility

The website uses a viewport meta tag to support different screen sizes. Descriptive alternative text is included for images, and form fields have labels to improve accessibility.

## 8. Part 3 Changelog

### Enhancing Functionality and SEO

The following improvements were made for Part 3:

- Added JavaScript functionality to improve website interaction.
- Added a service search feature.
- Added a category filter to help visitors find services.
- Added an accordion for frequently asked questions.
- Added image lightbox functionality.
- Added client-side form validation.
- Added character counters to message fields.
- Added a response message after an enquiry form is submitted.
- Added functionality to prepare an email from the contact form.
- Added SEO titles and meta descriptions to the website pages.
- Added descriptive alternative text to images.
- Added robots.txt and sitemap.xml files.
- Improved the website's user experience and accessibility.

## 9. Future Improvements

Future improvements may include:

- Connecting the forms to a server or form-processing service.
- Implementing AJAX form submission.
- Adding more website content and images.
- Improving website loading speed.
- Publishing the website using a web hosting service.

## 10. Conclusion

The Second Chance Youth Foundation website provides information about the organisation and the support it offers to young adults. The Part 3 improvements focus on enhancing website functionality, improving user experience and applying search engine optimisation techniques.
