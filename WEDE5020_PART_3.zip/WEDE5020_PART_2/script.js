/* Part 3 JavaScript - The Second Chance Youth Foundation */

document.addEventListener("DOMContentLoaded", function () {

    // Update copyright year
    const year = document.getElementById("current-year");
    if (year) year.textContent = new Date().getFullYear();

    // FAQ accordion
    document.querySelectorAll(".faq-question").forEach(function (button) {
        button.addEventListener("click", function () {
            const answer = button.nextElementSibling;
            const isOpen = button.getAttribute("aria-expanded") === "true";
            button.setAttribute("aria-expanded", String(!isOpen));
            answer.hidden = isOpen;
        });
    });

    // Dynamic services
    const services = [
        { title: "Accommodation Support", category: "living", description: "Assistance with safe and stable accommodation for eligible young adults transitioning towards independent living." },
        { title: "Career Guidance", category: "career", description: "Guidance to identify career goals, explore opportunities and prepare for the workplace." },
        { title: "Educational Support", category: "career", description: "Support with identifying learning opportunities and developing skills for future careers." },
        { title: "Life-Skills Training", category: "personal", description: "Practical skills to help young adults manage finances, responsibilities and everyday life." },
        { title: "Mentorship", category: "personal", description: "Guidance and encouragement from supportive mentors." },
        { title: "Employment Assistance", category: "career", description: "Help with job searching, applications and workplace preparation." }
    ];

    const serviceList = document.getElementById("services-list");
    const searchInput = document.getElementById("service-search");
    const filterSelect = document.getElementById("service-filter");
    const serviceCount = document.getElementById("service-count");

    function displayServices() {
        if (!serviceList) return;

        const term = searchInput ? searchInput.value.trim().toLowerCase() : "";
        const category = filterSelect ? filterSelect.value : "all";

        const filtered = services.filter(function (service) {
            const matchesText = (service.title + " " + service.description).toLowerCase().includes(term);
            const matchesCategory = category === "all" || service.category === category;
            return matchesText && matchesCategory;
        });

        serviceList.replaceChildren();

        filtered.forEach(function (service) {
            const article = document.createElement("article");
            article.className = "service-card";

            const heading = document.createElement("h3");
            heading.textContent = service.title;

            const paragraph = document.createElement("p");
            paragraph.textContent = service.description;

            article.append(heading, paragraph);
            serviceList.appendChild(article);
        });

        if (serviceCount) {
            serviceCount.textContent = filtered.length + " service(s) found.";
        }

        if (filtered.length === 0) {
            const empty = document.createElement("p");
            empty.className = "no-results";
            empty.textContent = "No services match your search. Please try another word or category.";
            serviceList.appendChild(empty);
        }
    }

    if (serviceList) displayServices();
    if (searchInput) searchInput.addEventListener("input", displayServices);
    if (filterSelect) filterSelect.addEventListener("change", displayServices);

    // Image gallery lightbox
    const lightbox = document.getElementById("image-lightbox");
    const lightboxImage = document.getElementById("lightbox-image");
    const closeLightbox = document.getElementById("lightbox-close");

    document.querySelectorAll("[data-lightbox]").forEach(function (button) {
        button.addEventListener("click", function () {
            if (!lightbox || !lightboxImage) return;
            lightboxImage.src = button.getAttribute("data-lightbox");
            lightbox.hidden = false;
            if (closeLightbox) closeLightbox.focus();
        });
    });

    function hideLightbox() {
        if (lightbox) lightbox.hidden = true;
    }

    if (closeLightbox) closeLightbox.addEventListener("click", hideLightbox);

    if (lightbox) {
        lightbox.addEventListener("click", function (event) {
            if (event.target === lightbox) hideLightbox();
        });
    }

    document.addEventListener("keydown", function (event) {
        if (event.key === "Escape") hideLightbox();
    });

    // Character counters
    [["message", "message-count"], ["contact-message", "contact-message-count"]].forEach(function (ids) {
        const field = document.getElementById(ids[0]);
        const counter = document.getElementById(ids[1]);

        if (field && counter) {
            const update = function () {
                counter.textContent = field.value.length + "/1000 characters";
            };
            field.addEventListener("input", update);
            update();
        }
    });

    // Enquiry form validation
    const enquiryForm = document.getElementById("enquiry-form");

    if (enquiryForm) {
        enquiryForm.addEventListener("submit", function (event) {
            event.preventDefault();

            const response = document.getElementById("enquiry-response");
            if (!enquiryForm.reportValidity()) return;

            const type = document.getElementById("enquiry-type").value;
            const interest = document.getElementById("service-interest").value;

            const replies = {
                assistance: "Thank you for requesting assistance. Our team can review your selected service and discuss eligibility and availability with you.",
                volunteer: "Thank you for your interest in volunteering. Please use the contact page to send your details to the foundation.",
                sponsor: "Thank you for considering sponsorship. The foundation can discuss possible support and partnership arrangements with you.",
                employer: "Thank you for your partnership enquiry. The foundation can discuss employment and collaboration opportunities with you."
            };

            const serviceNames = {
                accommodation: "Accommodation Support",
                career: "Career Guidance",
                education: "Educational Support",
                "life-skills": "Life-Skills Training",
                mentorship: "Mentorship",
                employment: "Employment Assistance",
                general: "general information"
            };

            response.textContent = replies[type] + " Your selected interest: " + serviceNames[interest] +
                ". This demonstration form does not store or send your information; please contact the foundation directly for a response.";

            response.classList.add("success-message");
        });
    }

    // Contact form: validate and prepare an email
    const contactForm = document.getElementById("contact-form");

    if (contactForm) {
        contactForm.addEventListener("submit", function (event) {
            event.preventDefault();
            if (!contactForm.reportValidity()) return;

            const name = document.getElementById("contact-name").value.trim();
            const email = document.getElementById("contact-email").value.trim();
            const phone = document.getElementById("contact-phone").value.trim();
            const type = document.getElementById("message-type").value;
            const message = document.getElementById("contact-message").value.trim();

            const subject = encodeURIComponent("Website contact: " + type);

            const body = encodeURIComponent(
                "Full name: " + name +
                "\nEmail: " + email +
                "\nPhone: " + (phone || "Not provided") +
                "\nMessage type: " + type +
                "\n\nMessage:\n" + message
            );

            const recipient = "info@secondchanceyouth.org";
            const response = document.getElementById("contact-response");

            response.textContent = "Your email application is opening with your message addressed to " +
                recipient + ". Please review it and press Send in your email application.";

            window.location.href = "mailto:" + recipient + "?subject=" + subject + "&body=" + body;
        });
    }

});